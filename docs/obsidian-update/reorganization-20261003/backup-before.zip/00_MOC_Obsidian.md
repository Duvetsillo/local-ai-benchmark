---
tipo: indice-general
fecha: 2026-09-30
tags: [moc, proyectos, inicio]
---

# Mapa general de proyectos

Índice general para vincular las áreas del vault sin reemplazar MOC anteriores.

## Proyectos

- [[Proyecto Aetherion/00_Gobierno/00_MOC_Aetherion]] — benchmarking local y cliente de escritorio.
- [[Proyecto FRIDAY/FRIDAY_Blueprint]] — identidad y documentación operativa.
- [[Proyecto Ultron/README]] — integración de Ultron con Obsidian.
- [[Karen Asistant/00_MOC_Vault 1]] — mapa de Karen y homelab.

## Continuidad

Cada proyecto conserva carpeta, estado, decisiones y cronología. El enlace expresa contexto documental y no implica integración técnica. Confirmar fecha y evidencia antes de ejecutar instrucciones operativas.
