---
proyecto: Aetherion
tipo: riesgos
tags: [aetherion, riesgos, calidad]
---

# Riesgos y controles

| Riesgo | Impacto | Control |
|---|---|---|
| Error de arranque | Cliente distribuido inutilizable | Traceback, build de diagnóstico, prueba interactiva. |
| Validador simple | Sobreinterpretación de puntuación | Mostrar regla y límites. |
| Presión de memoria | Equipo lento o agotamiento de RAM | Mostrar hardware y permitir detener de forma segura. |
| Endpoint remoto | Cambia destino de prompts | Indicar servidor y revisar privacidad. |
| Resultados compartidos | Exposición de prompts/equipo | Inspección antes de compartir. |
| Runtime incompatible | Fallo o CPU fallback | Registrar build, driver y runtime efectivo. |
| Schema evoluciona | Historial antiguo deja de leerse | Versionado, migraciones y pruebas. |
| Imports ausentes en PyInstaller | Falla solo en empaquetado | Revisar warnings y validar en perfil limpio. |
| Documentación atrasada | Operación engañosa | Marcar fecha y fuente de cada estado. |

## Prioridad actual

El error genérico de arranque sigue abierto. No declarar estable el ejecutable hasta reproducir y cerrar el incidente. No inferir causa solo por advertencias de PyInstaller.

## Gestión

Convertir riesgo en acción con dueño, criterio de cierre y fecha. Diferenciar potencial de incidente observado.
