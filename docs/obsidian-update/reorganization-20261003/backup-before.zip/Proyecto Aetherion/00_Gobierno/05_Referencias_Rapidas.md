---
proyecto: Aetherion
tipo: referencia-rapida
tags: [aetherion, rutas]
---

# Referencias rápidas

## Repositorio

C:/Users/Dayve/Desktop/Carpetas/Local_AI_Benchmark

## Código

- GUI: src/local_ai_benchmark/client/desktop.py
- Tema: src/local_ai_benchmark/client/theme.py
- Motor: src/local_ai_benchmark/engine.py
- Providers: src/local_ai_benchmark/providers.py
- Suite: src/local_ai_benchmark/tasks.py
- Tests: tests/

## Build

- Spec: Aetherion-Client.spec
- Script: build_client.py
- Salida: dist/Aetherion-Client.exe
- Descarga: downloads/Aetherion-Client.exe

## Datos

- Resultados documentados: %LOCALAPPDATA%/Aetherion/results.
- Ollama: http://127.0.0.1:11434.
- GGUF: carpeta seleccionable en la GUI.

## Categorías

general, coding, math, json, spanish.

## Recordatorio

Build terminada no significa aplicación probada. Revisar [[Proyecto Aetherion/04_Calidad/02_Incidente_Arranque_Cliente]].
