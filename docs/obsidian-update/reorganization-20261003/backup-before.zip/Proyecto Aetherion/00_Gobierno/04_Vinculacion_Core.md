---
proyecto: Aetherion
tipo: vinculacion-core
relacionado:
  - "[[Proyecto Ultron/README]]"
  - "[[Proyecto FRIDAY/FRIDAY_Blueprint]]"
tags: [aetherion, ultron, friday, vinculacion]
---

# Vinculación con el ecosistema central

## Relación con Ultron

Aetherion puede aportar una utilidad técnica local: perfilar hardware, descubrir modelos y comparar corridas. Puede servir como herramienta del ecosistema documentado por Ultron; no se asume API compartida, RAG ni control por voz.

## Relación con F.R.I.D.A.Y.

F.R.I.D.A.Y. representa el frente operativo y de continuidad. Los datos de benchmark podrían orientar qué modelo local ejecutar, pero esa relación es conceptual hasta que exista una integración implementada.

## Límites

- Los proyectos conservan repositorios, dependencias y ciclos de entrega independientes.
- Un vínculo en Obsidian no equivale a integración técnica.
- No compartir credenciales ni datos privados mediante las notas.
- Aetherion no escribe automáticamente en la memoria de otros proyectos.

## Si se implementa una integración

Documentar contrato y límites: origen/destino, formato, autenticación, flujo de datos, errores, permisos y cómo desactivar la integración. Enlazar el código o diseño concreto, no solo el roadmap.
