---
proyecto: Aetherion
tipo: glosario
tags: [aetherion, glosario]
---

# Glosario

- **Aetherion:** cliente de escritorio del producto.
- **Local AI Benchmark:** paquete/repositorio con GUI, CLI, motor y dashboard.
- **Proveedor:** runtime que recibe prompt y genera respuesta.
- **Ollama:** runtime local con API HTTP.
- **GGUF:** formato de modelos usado con llama.cpp.
- **llama.cpp:** runtime local integrado mediante llama-cpp-python.
- **Suite:** conjunto de tareas de una corrida.
- **Tarea determinista:** prompt y criterio diseñados para salida repetible.
- **Validador:** regla que produce pass/fail/no calificado.
- **TTFT:** tiempo hasta primer token.
- **Tokens/s:** velocidad derivada de conteo y duración.
- **Telemetría:** medición de hardware/runtime.
- **PyInstaller:** empaquetador de aplicación Python.
- **Spec:** archivo de opciones de PyInstaller.
- **Build:** artefacto de compilación.
- **Release:** build verificada y preparada para distribución.
- **Traceback:** detalle de llamadas que ubica excepción.
- **MOC:** mapa de contenido enlazado en Obsidian.
