---
proyecto: Aetherion
tipo: fuentes
tags: [aetherion, auditoria, certeza]
---

# Fuentes y certeza

## Archivos contrastados

README: propósito, instalación, privacidad y rutas.
pyproject.toml: versiones, extras y entrypoints.
engine.py, providers.py, tasks.py, models.py: ejecución.
client/desktop.py, theme.py, storage.py y hardware.py: GUI y datos.
Aetherion-Client.spec y build_client.py: empaquetado.
tests: inventario de archivos de prueba.
Git: rama, commits recientes y diff del binario.

## Historial de herramientas

Se observó ventana titulada “Unhandled exception in script”. No se obtuvo texto expandido ni traceback. El binario fue reconstruido; la operación no resolvió el arranque.

## Etiquetas recomendadas

- **Hecho:** lectura directa de fuente o configuración.
- **Observado:** ocurrió en un entorno y momento concretos.
- **Inferido:** plausible, aún no reproducido.
- **Planeado:** propuesta sin implementación.
- **No verificado:** no se probó.

Toda nota que influya una operación o release debería indicar fuente y fecha de revisión.
