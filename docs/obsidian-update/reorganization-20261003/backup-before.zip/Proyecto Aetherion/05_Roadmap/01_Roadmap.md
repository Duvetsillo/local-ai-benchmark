---
proyecto: Aetherion
tipo: roadmap
actualizado: 2026-09-30
tags: [aetherion, roadmap]
---

# Roadmap

## Fase 0 — Arranque Windows

- [ ] Capturar traceback exacto.
- [ ] Resolver diferencia entre fuente y exe congelado.
- [ ] Confirmar recursos Tcl/Tk e imports requeridos.
- [ ] Abrir versión con paleta actual.
- [ ] Revisar modificación binaria en downloads.
- [ ] Registrar hash, entorno y evidencia.

Salida: ventana visible, sin excepción, navegación básica. Hasta lograrlo, la distribución no está validada.

## Fase 1 — Congelar interfaz

- [ ] Centralizar colores directos de desktop.py.
- [ ] Revisar contraste, DPI y tamaño mínimo.
- [ ] Confirmar paleta en exe, no solo fuente.
- [ ] Mantener alcance visual separado del motor.

## Fase 2 — Repetibilidad

- [ ] Unificar metadatos de versión/runtime.
- [ ] Aclarar formatos JSON del motor y del cliente.
- [ ] Considerar repeticiones estadísticas.
- [ ] Mostrar fuentes y ausencia de métricas.

## Fase 3 — Calidad de evaluación

- [ ] Diseñar validadores semánticos mejores.
- [ ] Agregar casos adversariales.
- [ ] Comparar versiones por equipo/backend.
- [ ] Exportar con revisión de datos sensibles.

## Fase 4 — UX y accesibilidad

- [ ] Validar errores/estados vacíos.
- [ ] Revisar teclado, contraste y DPI.
- [ ] Mejorar mensajes de resolución.

## Fase 5 — Historial

- [ ] Definir retención.
- [ ] Mantener lectores de esquemas previos.
- [ ] Crear exportación transparente.

Las fases posteriores son propuestas, no funcionalidades confirmadas.
