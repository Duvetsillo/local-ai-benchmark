---
proyecto: Aetherion
tipo: operaciones
tags: [aetherion, setup, local]
---

# Instalación y operación

## Requisitos documentados

Python 3.11+ para desarrollar; Ollama para ese backend; psutil opcional para telemetría; nvidia-smi opcional para GPU NVIDIA; llama-cpp-python opcional para GGUF; PyInstaller para construir el cliente.

## Cliente distribuido

El README dice descargar downloads/Aetherion-Client.exe, abrir, elegir modelo/suite y consultar JSON local. La versión actual requiere resolver el incidente de arranque primero.

## Desarrollo

El README propone entorno virtual, instalación de extras, comandos CLI y dashboard local. Aislar el Python de desarrollo facilita reproducir build y no depender de paquetes globales.

## Ollama

Endpoint esperado: http://127.0.0.1:11434. Revisar que el servicio responda y que ollama list muestre el modelo. Evitar lanzar una segunda instancia de servidor si ya existe una activa.

## GGUF

Elegir carpeta personalizada o usar la predeterminada del proveedor. Los modelos pueden ocupar muchos GB y requerir runtime compatible. GPU depende del build de llama-cpp-python.

## Operación prudente

Ejecutar con el equipo estable; cerrar cargas competidoras; no instalar runtime sin revisar compatibilidad; capturar mensajes exactos; registrar versiones de Python, PyInstaller, runtime y driver al diagnosticar.
