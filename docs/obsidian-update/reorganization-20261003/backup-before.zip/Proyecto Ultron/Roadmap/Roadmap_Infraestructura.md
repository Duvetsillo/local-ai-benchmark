# 🏗️ Roadmap de Infraestructura

Enfoque en el hardware y la capa de transporte de datos.

## 🛠️ Tareas Pendientes
- [ ] **Optimización de LXC:** Revisar consumo de RAM del contenedor 105 para evitar OOM durante entrenamientos.
- [ ] **Automatización de Servidor:** Configurar `karen.service` como systemd para arranque automático tras reboot.
- [ ] **Monitoreo de Salud:** Implementar un dashboard simple o script de chequeo para los endpoints `/salud` de Flask y Ollama.
- [ ] **Sincronización de Vault:** Asegurar que la carpeta de Obsidian sea accesible y writable por los agentes.
