# ⚡ Roadmap de Ultron (Ejecución y Control)

Enfoque en el brazo ejecutor y la automatización.

## 🛠️ Tareas Pendientes
- [ ] **Control de OS Avanzado:** Implementar scripts para gestión de ventanas y automatización de teclado/ratón (PyAutoGUI).
- [ ] **Integración Proxmox:** Crear comandos de voz para encender/apagar/reiniciar LXCs específicos.
- [ ] **Sincronización de Proyectos:** Automatizar el commit y push de los avances al repo de GitHub.
- [ ] **Sistema de Alertas:** Que Ultron pueda notificar al Jefe sobre eventos críticos en el servidor.
