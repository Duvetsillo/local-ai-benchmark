# 🧠 Roadmap de Inteligencia y Memoria

Enfoque en el "cerebro" y la persistencia de datos.

## 🛠️ Tareas Pendientes
- [ ] **Reparación de Tool-Calling Local:** Diagnosticar y corregir el fallback genérico de `qwen3:8b`.
- [ ] **Memoria Persistente (SQLite):** Implementar base de datos para que Karen/Ultron recuerden conversaciones pasadas fuera del contexto inmediato.
- [ ] **RAG (Retrieval Augmented Generation):** Conectar el modelo directamente al Vault de Obsidian para respuestas basadas en documentos reales.
- [ ] **Sintonía de Personalidad:** Refinar el balance entre "Jefe" y "Señor" según la preferencia del usuario.
