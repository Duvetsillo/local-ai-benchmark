# 🗺️ Roadmap Maestro: Ecosistema Ultron & Karen

Este es el mapa estratégico para la evolución de los asistentes personales del Jefe. El objetivo es la convergencia entre la capacidad de ejecución de **Ultron** y la interfaz de voz de **Karen**.

## 🎯 Objetivos Principales
1. **Estabilidad Total:** Eliminar los fallos de tool-calling del modelo local.
2. **Sincronización de Identidad:** Que Karen y Ultron compartan la misma base de conocimientos (Vault de Obsidian).
3. **Autonomía Ejecutiva:** Que la voz de Karen pueda disparar las acciones de Ultron en Windows y Proxmox.

## 📂 Estructura de Documentación
- [[Roadmap_Infraestructura]] - Hardware, LXC, Proxmox y Redes.
- [[Roadmap_Inteligencia]] - Modelos, Prompts, Memoria y RAG.
- [[Roadmap_Karen_Voz]] - Wake word, STT, TTS y cliente Windows.
- [[Roadmap_Ultron_Ejecucion]] - Control de OS, Automation y Tool-calling.

## 🚀 Hitos Inmediatos
- [ ] Reparación del modelo local (`qwen3:8b`) $\rightarrow$ Tool-calling funcional.
- [ ] Implementación del modelo `.onnx` de Wake Word en el cliente de Karen.
- [ ] Creación del índice maestro de conocimiento en Obsidian.
